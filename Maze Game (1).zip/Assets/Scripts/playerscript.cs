using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class playerscript : MonoBehaviour
{
    public float speed = 1f;
    public float rotSpeed = 20f;

    GameObject gameManager;
    GameObject blaster;

    // Start is called before the first frame update
    void Start()
    {
        gameManager = GameObject.FindWithTag("GameController");
        blaster = GameObject.FindWithTag("Blast");

    }

    // Update is called once per frame
    void Update()
    {
        if (Input.GetKey(KeyCode.UpArrow) || Input.GetKey(KeyCode.W ))
        {
            transform.Translate(Vector3.forward * speed * Time.deltaTime);
        }

        if (Input.GetKey(KeyCode.DownArrow) || Input.GetKey(KeyCode.S ))
        {
            transform.Translate(Vector3.back * speed * Time.deltaTime);
        }

        if (Input.GetKey(KeyCode.LeftArrow) || Input.GetKey(KeyCode.A))
        {
            transform.Translate(Vector3.left * speed * Time.deltaTime);
        }

        if (Input.GetKey(KeyCode.RightArrow) || Input.GetKey(KeyCode.D))
        {
            transform.Translate(Vector3.right * speed * Time.deltaTime);
        }

        if (Input.GetKey(KeyCode.Q))
        {
            transform.Rotate(Vector3.down * rotSpeed * Time.deltaTime);
           
        }

        if (Input.GetKey(KeyCode.E))
        {
            transform.Rotate(Vector3.up * rotSpeed * Time.deltaTime);
        }
    }

    private void OnTriggerEnter(Collider other)
    {
        if(other.gameObject.tag == "Coin")
        {
            
            Debug.Log("coin");
            gameManager.GetComponent<GameManager>().Score();
            other.gameObject.SetActive(false);
        }

        if(other.gameObject.tag == "Win")
        {
            Debug.Log("win");
            gameManager.GetComponent<GameManager>().Win();

        }

        if(other.gameObject.tag == "Blast")
        {
            Debug.Log("Blast");
            blaster.GetComponent<EnemyController>().Blast();
            gameManager.GetComponent<GameManager>().GameOver();
        }
    }

}
