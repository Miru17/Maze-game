using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemyController : MonoBehaviour
{
    public Animator blaster;

    public void Blast()
    {
        blaster.SetTrigger("attack01");
    }
}
