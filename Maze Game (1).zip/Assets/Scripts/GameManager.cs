using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class GameManager : MonoBehaviour
{
    public GameObject[] spawnpoint;
    public GameObject player;

    public Text score;
    private static int  scoreValue = 1;

    public GameObject win;
    public GameObject gameOver;

    Vector3 spawnLocation;

    private void Awake()
    {
        spawnpoint = GameObject.FindGameObjectsWithTag("SpawnPoint");
    }

    private void Start()
    {
        player = (GameObject)Resources.Load("Player", typeof(GameObject));

        spawnLocation = player.transform.position;
        ReSpawn();
    }
    public void ReSpawn()
    {   
        int spawn = Random.Range(0, spawnpoint.Length);
        GameObject.Instantiate(player, spawnpoint[spawn].transform.position, Quaternion.identity);
    }

    public  void Score()
    {
        score.text = "Score : " + scoreValue;
        scoreValue += 1;
    }

    public void Win()
    {
        win.SetActive(true);
    }

    public void GameOver()
    {
        gameOver.SetActive(true);
    }

    public void Reset()
    {
        SceneManager.LoadScene(0);
    }
}
